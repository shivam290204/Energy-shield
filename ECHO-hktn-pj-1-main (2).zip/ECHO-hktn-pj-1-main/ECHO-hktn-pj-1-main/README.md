# ECHO-hktn-pj-1

This is a dashboard of a energy theft detection website which contain three modules 
and in backend there is code which train on predefined data and do some prediction
